﻿using System;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DAL
{
    class Bin<T> : DataProvider<T>
    {
        public Bin() : base()
        { }

        public virtual void SerializeBIN(List<T> list)
        {
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream(path + "\\" + typeof(T).ToString() + "List.bin", FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream, list);
            stream.Close();
        }

        public virtual void DeserializeBIN(ref List<T> list)
        {
            if (File.Exists(path + "\\" + typeof(T).ToString() + "List.bin"))
            {
                IFormatter formatter = new BinaryFormatter();
                Stream stream = new FileStream(path + "\\" + typeof(T).ToString() + "List.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
                list = (List<T>)formatter.Deserialize(stream);
                stream.Close();
            }
            else
                .Empty();
        }
    {
    }
}
