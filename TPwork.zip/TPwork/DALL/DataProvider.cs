﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DAL
{
    public class DataProvider<T>
    {
        public string path { get; }
        public DataProvider()
        {
            path = Path.Combine(
                   Path.GetDirectoryName(
                   System.Reflection.Assembly.GetExecutingAssembly().Location), "Info");
            Directory.CreateDirectory(path);
            Console.WriteLine(path);
        }
        public void Write()
        {
            Console.WriteLine(path);
        }


        public virtual void CleanInfo()
        {
            File.Delete(path + "\\" + typeof(T).ToString() + "List.xml");
            File.Delete(path + "\\" + typeof(T).ToString() + "List.json");
            File.Delete(path + "\\" + typeof(T).ToString() + "List.bin");
        }
    }
}
