﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MassageB
{
    public class MassageBox
    {
        public static void Start()
        {
            Console.WriteLine(@"Choose operation:  
                    1) - Manage Groups 
                    2) - Manage Students
                    3) - Manage Subject
                    9) - Exit");
        }

        public static void StartStudent()
        {
            Console.WriteLine(@"Choose operation:                      
                    1) - Add student
                    2) - Show students                    
                    3) - Del student
                    4) - Search student for
                    5) - Change student info
                    9) - Return");
        }

        public static void StartGroup()
        {
            Console.WriteLine(@"Choose operation:  
                    1) - Add group 
                    2) - Show groups                    
                    3) - Del group
                    9) - Return");
        }

        public static void StudentNameAndGroup()
        {
            Console.WriteLine("Enter name of group and name of student");
        }

        public static void StartSubject()
        {
            Console.WriteLine(@"Choose operation:
                    1) Add subject
                    2) Del subject
                    3) Show subjects
                    9) Return ");
        }

        public static void ShowSub(string name)
        {
            Console.WriteLine(name);
        }

        public static void SubjectName()
        {
            Console.WriteLine("Enter subject name");
        }

        public static void ShowEst(double e, string name)
        {
            Console.WriteLine(e + " " + name);
        }

        public static void Changing()
        {
            Console.WriteLine(@"Choose what change:
                    1) Name
                    2) Surname
                    3) Estimate");
        }

        public static void NewValue()
        {
            Console.WriteLine("Enter new value");
        }

        public static void StudentId()
        {
            Console.WriteLine("Enter student id");
        }

        public static void StudentSName()
        {
            Console.WriteLine("Enter student surname");
        }

        public static void StudentSearch()
        {
            Console.WriteLine(@"Choose way of searching:
                    1) For name
                    2) For surname
                    3) For Id");
        }

        public static void ChooseOne()
        {
            Console.WriteLine(@"Choose way of search:
                      1) - only student name
                      2) - group and student name");
        }

        public static void ChooseTwo()
        {
            Console.WriteLine(@"Choose way of search:
                      1) - show group
                      2) - show all");
        }

        public static void Table()
        {
            Console.WriteLine("Name Surname Group ID");
        }

        public static void GroupName()
        {
            Console.WriteLine("Enter name of group");
        }

        public static void StudentName()
        {
            Console.WriteLine("Enter name of student");
        }

        public static void CreateStudent()
        {
            Console.WriteLine(@"Enter group name, student name, surname, id");
        }


        public static void WrongName()
        {
            Console.WriteLine("Wrong name");
        }

        public static void EmptyGroup()
        {
            Console.WriteLine("This group is empty");
        }

        public static void EmptyStudents()
        {
            Console.WriteLine("There are no sudents");
        }

        public static void NoStudent()
        {
            Console.WriteLine("No such student");
        }

        public static void NoGroup()
        {
            Console.WriteLine("No any group");
        }

        public static void NoGroup2()
        {
            Console.WriteLine("No such group");
        }

        public static void ShowName(string group)
        {
            Console.WriteLine("This student in group: "+ group);
        }
    }
}
