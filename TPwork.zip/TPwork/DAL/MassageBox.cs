﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Massage
{
    public class MassageBox
    {
        public static void Start()
        {
            Console.WriteLine(@"Choose operation:  
                    1) - Manage Groups 
                    2) - Manage Students
                    3) - Manage Subject
                    4) - Manage Data
                    9) - Exit");
        }

        public static void StartStudent()
        {
            Console.WriteLine(@"Choose operation:                      
                    1) - Add student
                    2) - Show students                    
                    3) - Del student
                    4) - Search student for
                    5) - Change student info
                    6) - Show estimate                   
                    9) - Return");
        }

        public static void StartSerialization()
        {
            Console.WriteLine(@"Choose operation:
                    1) - Save Data
                    2) - Load Data
                    9) - Return");
        }

        public static void NoSubject()
        {
            Console.WriteLine("There are no subjects");
        }

        public static void ShowAllEst(string name, string surname)
        {
            Console.WriteLine(name + " " + surname);
        }

        public static void EnterEst()
        {
            Console.WriteLine("Enter estimate");
        }

        public static void Empty()
        {
            Console.WriteLine("File does not exist");            
        }

        public static void SubName()
        {
            Console.WriteLine("Enter subject name");
        }

        public static void Avg()
        {
            Console.WriteLine("Enter avg");
        }

        public static void StartGroup()
        {
            Console.WriteLine(@"Choose operation:  
                    1) - Add group 
                    2) - Show groups                    
                    3) - Del group
                    4) - Change group name
                    9) - Return");
        }

        public static void StudentNameAndGroup()
        {
            Console.WriteLine("Enter name of group and name of student");
        }

        public static void Exist()
        {
            Console.WriteLine("This student exist");
        }

        public static void GExist()
        {
            Console.WriteLine("This group exist");
        }

        public static void StartSubject()
        {
            Console.WriteLine(@"Choose operation:
                    1) Add subject
                    2) Del subject
                    3) Show subjects
                    9) Return ");
        }

        public static void ShowSub(string name)
        {
            Console.WriteLine(name);
        }

        public static void SubjectName()
        {
            Console.WriteLine("Enter subject name");
        }

        public static void ShowEst(double e, string name)
        {
            Console.WriteLine(e + " " + name);
        }

        public static void Changing()
        {
            Console.WriteLine(@"Choose what change:
                    1) Name
                    2) Surname
                    3) Estimate
                    9) Return");
        }

        public static void WrongFormat()
        {
            Console.WriteLine("Wrong data format");
        }

        public static void NewValue()
        {
            Console.WriteLine("Enter new value");
        }

        public static void StudentId()
        {
            Console.WriteLine("Enter student id");
        }

        public static void StudentSName()
        {
            Console.WriteLine("Enter student surname");
        }

        public static void StudentSearch()
        {
            Console.WriteLine(@"Choose way of searching:
                    1) For name
                    2) For surname
                    3) For Id
                    4) For avg
                    9) Return");
        }

        public static void ChooseOne()
        {
            Console.WriteLine(@"Choose way of search:
                      1) - only student name
                      2) - group and student name");
        }

        public static void ChooseTwo()
        {
            Console.WriteLine(@"Choose way of search:
                      1) - show group
                      2) - show all");
        }

        public static void Table()
        {
            Console.WriteLine("Name Surname Group ID Avg");
        }

        public static void GroupName()
        {
            Console.WriteLine("Enter name of group");
        }

        public static void OldGroupName()
        {
            Console.WriteLine("Enter name of group whicn name you want to change");
        }

        public static void NewGroupName()
        {
            Console.WriteLine("Enter new name of group");
        }

        public static void StudentName()
        {
            Console.WriteLine("Enter name of student");
        }

        public static void CreateStudent()
        {
            Console.WriteLine(@"Enter group name, student name, surname, id");
        }

        public static void WrongName()
        {
            Console.WriteLine("Wrong name");
        }

        public static void EmptyGroup()
        {
            Console.WriteLine("This group is empty");
        }

        public static void EmptyStudents()
        {
            Console.WriteLine("There are no sudents");
        }

        public static void NoStudent()
        {
            Console.WriteLine("No such student");
        }

        public static void NoGroup()
        {
            Console.WriteLine("No any group");
        }

        public static void NoGroup2()
        {
            Console.WriteLine("No such group");
        }

        public static void ShowName(string group)
        {
            Console.WriteLine("This student in group: "+ group);
        }
    }
}
