﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Massage;
using DAL_;

namespace BLL
{
    [Serializable]
    public class University
    {
        List<Group> groups = new List<Group>();
        List<Student> students = new List<Student>();
        static Bin bin = new Bin();
        static List<string> sub = new List<string>();

        public University()
        {

        }                

        public void DelSubject(string name)
        {
            try {
                int i = GetIndex(name);
                sub.RemoveAt(i);
                    for (int j = 0; j < students.Count; j++)
                    {
                        students[j].GetEst().RemoveAt(i);
                    }
                }
            catch (ArgumentOutOfRangeException) {
                MassageBox.WrongName();
            }
        }

        public int GetIndex(string name)
        {
            return sub.IndexOf(name);
        }

        public void AddSubject(string name)
        {
            sub.Add(name);
            for (int i = 0; i < students.Count; i++)
               students[i].GetEst().Add(default);
        }

        public void Serialize()
        {
            bin.SerializeBin(groups);
            bin.SerializeBin(students);
            bin.SerializeBin(sub);
        }

        public void DeSerialize()
        {            
            bin.DeserializeBin(ref groups);
            bin.DeserializeBin(ref students);
            bin.DeserializeBin(ref sub);
        }

        public void ChangeGroupName(string oldone, string newone)
        {
            foreach(Group a in groups)
            {
                if (a.GetName() == oldone) a.SetName(newone); 
            }

            foreach(Student a in students)
            {
                if (a.GetGroup() == oldone) a.SetGroup(newone);
            }
        }

        public List<Student> GetStud()
        {
            return students;
        }

        public List<Group> GetGroup()
        {
            return groups;
        }

        public void SetGroup(List<Group> list)
        {
            this.groups = list;
        }

        public void AddGroup(string name)
        {
            int q = 0;

            foreach(Group a in groups)
            {
                if(a.GetName() == name)
                {
                    q = 1;
                }
            }

            if (q == 0)
            {
                Group gr = new Group(name);
                groups.Add(gr);
            }
            else MassageBox.GExist();          
        }

        public void AddStudent(Student st, string name)
        {
            int q = 0;
            for(int i = 0; i < groups.Count; i++)
            {
                if (groups[i].GetName() == name)
                {
                    st.SetGroup(name);
                    groups[i].AddStudent(st);
                    students.Add(st);
                   
                    q = 1;
                    break;
                }
            } 

            if(q == 0)
            {
                MassageBox.WrongName();   
            }
        }

        public void DelStudent(string id)
        {
            int q = 0;
            for (int i = 0; i < groups.Count; i++)
            {
                for (int j = 0; j < groups[i].GetList().Count; j++)
                {
                    if (groups[i].GetList()[j].GetId() == id)
                    {
                        groups[i].GetList().RemoveAt(j);
                        q = 1;
                        break;
                    }
                }
            }

            for(int i = 0; i < students.Count; i++)
            {
                if (students[i].GetId() == id) students.RemoveAt(i);
            }

            if (q == 0)
            {
                MassageBox.NoStudent();
            }
        }

        public int IsExistSt(string id)
        {
            foreach (Student a in students)
            {
                if (a.GetId() == id)
                {
                    MassageBox.Exist();
                    return 1;
                }
            }
                return 0;
        }

        public int IsExistSt2(string id)
        {
            foreach (Student a in students)
            {
                if (a.GetId() == id)
                {                    
                    return 1;
                }
            }
            return 0;
        }

        public int IsExistSub(string name)
        {
            foreach (string a in sub)
            {
                if (a == name)
                {
                    return 1;
                }
            }
            return 0;
        }

        public void SearchStudentName(string name)
        {
            int q = 0;
            for (int i = 0; i < groups.Count; i++)
            {
                for(int j = 0; j < groups[i].GetList().Count; j++)
                {
                    if (groups[i].ReturnName(j) == name)
                    {
                        MassageBox.ShowName(groups[i].GetName());
                        q = 1;
                        break;
                    }
                }                
            }

            if (q == 0)
            {
                MassageBox.NoStudent();
            }
        }

        public void SearchStudentSName(string sname)
        {
            int q = 0;
            for (int i = 0; i < students.Count; i++)
            {              
                
                if (students[i].GetSName() == sname)
                {
                    MassageBox.ShowName(groups[i].GetName());
                    q = 1;
                    break;
                }                
            }

            if (q == 0)
            {
                MassageBox.NoStudent();
            }
        }

        public void SearchStudentId(string id)
        {
            int q = 0;
            for (int i = 0; i < students.Count; i++)
            {

                if (students[i].GetId() == id)
                {
                    MassageBox.ShowName(groups[i].GetName());
                    q = 1;
                    break;
                }
            }

            if (q == 0)
            {
                MassageBox.NoStudent();
            }
        }

        public Student SearchStudentId_r(string id)
        {
            
            for (int i = 0; i < students.Count; i++)
            {

                if (students[i].GetId() == id)
                {
                    //MassageBox.ShowName(groups[i].GetName());
                    
                    
                    return students[i];                    
                }
            }

            MassageBox.NoStudent();   
            return null;            
        }

        public void SearchStudentAvg(double avg)
        {
            int q = 0;
            for (int i = 0; i < students.Count; i++)
            {

                if (students[i].GetAvg() == avg)
                {
                    MassageBox.ShowAllEst(students[i].GetName(), students[i].GetSName());
                    q = 1;                   
                }
            }

            if (q == 0)
            {
                MassageBox.NoStudent();
            }
        }

        public void ShowGroups()
        {
            if (groups.Count != 0)
            {
                for (int i = 0; i < groups.Count; i++)
                {
                    Console.WriteLine(groups[i].GetName());
                }
            } else
            {
                MassageBox.NoGroup();
            }
        }

        public int ExistGroup(string name)
        {
            for (int i = 0; i < groups.Count; i++)
            {
                if (groups[i].GetName() == name)
                {
                    return 1;
                }                
            }
            return 0;
        }

        public void ShowStudents()
        {
            if(students.Count == 0)
            {
                MassageBox.EmptyStudents();
            }
            else
            {
                MassageBox.Table();
                for (int i = 0; i < students.Count; i++)
                {                                
                    Console.WriteLine(students[i].GetName() + " " + students[i].GetSName() + " " + students[i].GetGroup() + " " + students[i].GetId() + " " + students[i].GetAvg());                                                                        
                }
            }                    
        }       

        public int GetSubCount()
        {
            return sub.Count();
        }

        public static int GetSubCount2()
        {
            return sub.Count();
        }

        public List<string> GetSub()
        {
            return sub;
        }

        public static string GetSub(int i)
        {
            return sub[i];
        }

        public void ShowStudents(string name)
        {
            int q = 0;
            for (int i = 0; i < groups.Count; i++)
            {
                if (groups[i].GetName() == name)
                {
                    for (int j = 0; j < groups[i].GetList().Count; j++)
                        Console.WriteLine(groups[i].ReturnName(j) + " " + groups[i].ReturnSName(j));
                    q = 1;
                    break;
                }
            }

            if (q == 0)
            {
                MassageBox.EmptyGroup();
            }
        }

        public void DelGroup(string name)
        {
            int q = 0;
            for (int i = 0; i < groups.Count; i++)
            {
                if (groups[i].GetName() == name)
                {
                    groups.RemoveAt(i);
                    q = 1;
                }
            }

            for (int i = 0; i < students.Count; i++)
            {
                if (students[i].GetGroup() == name)
                {
                    students.RemoveAt(i);                    
                }
            }

            if (q == 0)
            {
                MassageBox.NoGroup2();
            }
        }       
        
    }
}
