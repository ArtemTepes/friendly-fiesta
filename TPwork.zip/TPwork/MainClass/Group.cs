﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    [Serializable]
    public class Group
    {
        string name;
        List<Student> group = new List<Student>();

        public Group(string name)
        {
            this.name = name;
        }
        
        public string ReturnName(int j)
        {
            return group[j].GetName();
        }

        public string ReturnSName(int j)
        {
            return group[j].GetSName();
        }

        public string GetName()
        {
            return name;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public List<Student> GetList()
        {
            return group;
        }       

        public void AddStudent(Student st)
        {            
            group.Add(st);
        }        
    }
}
