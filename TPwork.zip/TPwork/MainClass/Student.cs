﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Massage;

namespace BLL
{
    [Serializable]
    public class Student
    {      
        string name;
        string sname;
        string id;
        string group;
        double avg = 0;

        List<double> estimate = new List<double>();


        public Student()
        {
            name = default;
            sname = default;
            id = default;
            group = default;
        }

        public Student(string name, string sname, string id)
        {
            this.name = name;
            this.sname = sname;           
            this.id = id;
            for (int i = 0; i < University.GetSubCount2(); i++)
            {
                estimate.Add(default);
            }
        }

        public void Avg()
        {
            double k = 0;
            for (int i = 0; i < estimate.Count; i++)
            {
                k += estimate[i];
            }
            avg = k / estimate.Count;
        }

        public void SetEst(double est, int i)
        {
            try
            {
                estimate[i] = est;
            }
            catch(ArgumentOutOfRangeException)
            {
                MassageBox.NoSubject();
            }
            
            Avg();
        }

        public List<double> GetEst()
        {
            return estimate;
        }

        public double GetAvg()
        {
            return avg;
        }

        public void ShowEst()
        {
            if (estimate != null)
            {
                for (int i = 0; i < estimate.Count; i++)
                {
                    MassageBox.ShowEst(estimate[i], University.GetSub(i));
                }
            }
            else MassageBox.NoSubject();
            
        }

        public string GetName()
        {
            return name;
        }

        public string GetSName()
        {
            return sname;
        }

        public string GetGroup()
        {
            return group;
        }

        public string GetId()
        {
            return id;
        }

        public void SetGroup(string name)
        {
            this.group = name;
        }

        public void SetId(string id)
        {
            this.id = id;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public void SetSName(string sname)
        {
            this.sname = sname;
        }
       
    }
}
