﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace DAL_
{
    public class DataProvider
    {
        public string path { get; }

        public DataProvider()
        {
            path = Path.Combine(
                   Path.GetDirectoryName(
                   System.Reflection.Assembly.GetExecutingAssembly().Location), "Info");
            Directory.CreateDirectory(path);            
        }

        public void Write()
        {
            Console.WriteLine(path);
        }
    }
}
