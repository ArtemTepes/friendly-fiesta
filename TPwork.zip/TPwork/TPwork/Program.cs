﻿using System;
using PL;

namespace TPwork
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.Start();
        }
    }
}
