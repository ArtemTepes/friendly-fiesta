﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Massage;
using BLL;

namespace PL
{
    public static class Menu
    {   
        static University nau = new University();

        public static University GetUniversity()
        {
            return nau;
        }

        public static void Start()
        {
            bool t = true;
            string a;
            nau.DeSerialize();
            

            while (t)
            {
                MassageBox.Start();
                a = Console.ReadLine();

                switch (a)
                {
                    case "1": //Groups
                        {
                            MenuGroup.Start();
                            break;
                        }

                    case "2": //Students
                        {
                            MenuStudents.Start();
                            break;
                        }

                    case "3": //Subjects
                        {
                            MenuSubject.Start();
                            break;
                        }

                    case "4": //Serialization
                        {
                            MenuSerialize.Start();
                            break;
                        }

                    case "9":
                        {
                            t = false;
                            break;
                        }

                }
            }
        }
    }
}
