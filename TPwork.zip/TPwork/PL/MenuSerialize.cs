﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL_;
using Massage;
using BLL;

namespace PL
{
    public class MenuSerialize
    {
        public static void Start()
        {
            
            bool t = true;
            string a;
            
            while (t)
            {
                MassageBox.StartSerialization();
                a = Console.ReadLine();

                switch(a)
                {
                    case "1": //Serialize
                        {
                            Menu.GetUniversity().Serialize();
                            
                            break;                            
                        }

                    case "2": //DeSerialize
                        {
                            Menu.GetUniversity().DeSerialize();
                            
                            
                            break;
                        }

                    case "9": //Return
                        {
                            t = false;
                            break;
                        }
                }
            }
        }
    }
}
