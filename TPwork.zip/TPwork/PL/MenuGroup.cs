﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Massage;
using BLL;

namespace PL
{
    class MenuGroup
    {
        public static void Start()
        {
            bool t = true;
            string a;            

            while (t)
            {
                MassageBox.StartGroup();
                a = Console.ReadLine();

                switch (a)
                {
                    case "1": //AddGroup
                        {
                            MassageBox.GroupName();
                            string b = Console.ReadLine();

                            Menu.GetUniversity().AddGroup(b);

                            break;
                        }

                    case "2": //ShowGroups
                        {
                            Menu.GetUniversity().ShowGroups();
                            break;
                        }

                    case "3": //DelGroup
                        {
                            MassageBox.GroupName();
                            string group = Console.ReadLine();
                            Menu.GetUniversity().DelGroup(group);

                            break;
                        }

                    case "4": //ChangeName
                        {
                            MassageBox.OldGroupName();
                            string group = Console.ReadLine();

                            if( Menu.GetUniversity().ExistGroup(group) == 0)
                            {
                                MassageBox.NoGroup2();
                                break;
                            }

                            MassageBox.NewGroupName();
                            string newgroup = Console.ReadLine();

                            Menu.GetUniversity().ChangeGroupName(group, newgroup);

                            break;
                        }
                    
                    case "9": //Return
                        {
                            t = false;
                            break;
                        }
                }

            }
        }
    }

}
