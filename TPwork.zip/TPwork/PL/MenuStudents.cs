﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Massage;
using BLL;
using System.Text.RegularExpressions;

namespace PL
{
    class MenuStudents
    {
        public static void Start()
        {
            bool t = true;
            string a;
            try
            {
                while (t)
                {
                    MassageBox.StartStudent();
                    a = Console.ReadLine();

                    switch (a)
                    {
                        case "1": //AddStudent
                            {
                                MassageBox.GroupName();

                                string group = Console.ReadLine();
                                if (Menu.GetUniversity().ExistGroup(group) == 0)
                                {
                                    MassageBox.NoGroup2();
                                    break;
                                }

                                MassageBox.StudentName();
                                string name = Console.ReadLine();
                                
                                string pattern = @"[\W, \d]";                                
                                if(Regex.IsMatch(name, pattern))
                                {
                                    MassageBox.WrongFormat();
                                    break;
                                }
                                

                                MassageBox.StudentSName();
                                string surname = Console.ReadLine();
                                if (Regex.IsMatch(surname, pattern))
                                {
                                    MassageBox.WrongFormat();
                                    break;
                                }

                                MassageBox.StudentId();
                                string id = (Console.ReadLine());
                                if (Menu.GetUniversity().IsExistSt(id) == 1) break;

                                Student st = new Student(name, surname, id);
                                Menu.GetUniversity().AddStudent(st, group);

                                break;
                            }

                        case "2": //ShowStudent
                            {
                                string q;
                                MassageBox.ChooseTwo();
                                q = Console.ReadLine();
                                switch (q)
                                {
                                    case "1":
                                        {
                                            MassageBox.GroupName();
                                            string group = Console.ReadLine();
                                            Menu.GetUniversity().ShowStudents(group);
                                            break;
                                        }
                                    case "2":
                                        {
                                            Menu.GetUniversity().ShowStudents();
                                            break;
                                        }
                                }

                                break;
                            }

                        case "3": //DelStudent
                            {
                                MassageBox.StudentId();
                                string name = Console.ReadLine();
                                Menu.GetUniversity().DelStudent(name);

                                break;
                            }

                        case "4": //SearchStudent
                            {

                                MassageBox.StudentSearch();
                                string c = Console.ReadLine();

                                switch (c)
                                {
                                    case "1":
                                        {
                                            MassageBox.StudentName();
                                            string name = Console.ReadLine();
                                            Menu.GetUniversity().SearchStudentName(name);

                                            break;
                                        }
                                    case "2":
                                        {
                                            MassageBox.StudentSName();
                                            string name = Console.ReadLine();
                                            Menu.GetUniversity().SearchStudentSName(name);

                                            break;
                                        }
                                    case "3":
                                        {
                                            MassageBox.StudentId();
                                            string name = Console.ReadLine();
                                            Menu.GetUniversity().SearchStudentId(name);

                                            break;
                                        }
                                    case "4":
                                        {
                                            MassageBox.Avg();
                                            double avg = Double.Parse(Console.ReadLine());
                                            Menu.GetUniversity().SearchStudentAvg(avg);
                                            break;
                                        }
                                    case "9":
                                        {

                                            break;
                                        }
                                }

                                break;
                            }

                        case "5": //ChangeStudInfo
                            {                                

                                int z = 1;

                                while (z == 1)
                                { 
                                  MassageBox.Changing();
                                string q = Console.ReadLine();
                                
                                    switch (q)
                                    {
                                        case "1":
                                            {
                                                MassageBox.StudentId();
                                                string id = Console.ReadLine();
                                                Student st = Menu.GetUniversity().SearchStudentId_r(id);
                                                if (Menu.GetUniversity().IsExistSt2(id) == 0) break;

                                                MassageBox.StudentName();
                                                string val = Console.ReadLine();
                                                st.SetName(val);
                                                break;
                                            }
                                        case "2":
                                            {
                                                MassageBox.StudentId();
                                                string id = Console.ReadLine();
                                                Student st = Menu.GetUniversity().SearchStudentId_r(id);
                                                if (Menu.GetUniversity().IsExistSt2(id) == 0) break;
                                                MassageBox.StudentSName();
                                                string val = Console.ReadLine();
                                                st.SetSName(val);
                                                break;
                                            }
                                        case "3":
                                            {
                                                MassageBox.StudentId();
                                                string id = Console.ReadLine();


                                                Student st = Menu.GetUniversity().SearchStudentId_r(id);
                                                if (Menu.GetUniversity().IsExistSt2(id) == 0) break;

                                                MassageBox.SubName();
                                                string subname = Console.ReadLine();
                                                if (Menu.GetUniversity().IsExistSub(subname) == 0)
                                                {
                                                    MassageBox.NoSubject();
                                                }

                                                MassageBox.EnterEst();
                                                double est = Double.Parse(Console.ReadLine());

                                                Student s = Menu.GetUniversity().SearchStudentId_r(id);

                                                s.SetEst(est, Menu.GetUniversity().GetIndex(subname));

                                                break;
                                            }
                                        case "9":
                                            {
                                                z = 0;
                                                break;
                                            }

                                    }
                                }


                                break;
                            }

                        case "6": //ShowEstimate
                            {
                                MassageBox.StudentId();
                                string studid = Console.ReadLine();

                                Student st = Menu.GetUniversity().SearchStudentId_r(studid);

                                try
                                {
                                    st.ShowEst();
                                }
                                catch (NullReferenceException)
                                {
                                    MassageBox.NoSubject();
                                };



                                break;
                            }

                        case "9": //Return
                            {
                                t = false;
                                break;
                            }
                    }

                }
            } catch(FormatException) { MassageBox.WrongFormat(); }
        }
    }
}