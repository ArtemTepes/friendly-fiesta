﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL;
using Massage;

namespace PL
{
    class MenuSubject
    {
        public static void Start()
        {
            bool t = true;
            string a;


            while (t)
            {
                MassageBox.StartSubject();
                a = Console.ReadLine();

                switch (a)
                {
                    case "1": //AddSubject
                        {
                            MassageBox.SubjectName();
                            string name = Console.ReadLine();
                            Menu.GetUniversity().AddSubject(name);
                            break;
                        }

                    case "2": //DelSubject
                        {
                            MassageBox.SubjectName();
                            string name = Console.ReadLine();
                            Menu.GetUniversity().DelSubject(name);
                            break;
                        }

                    case "3": //ShowSubjects
                        {
                            if (University.GetSubCount2() == 0) break;
                            for (int i = 0; i < University.GetSubCount2(); i++)
                            {
                                MassageBox.ShowSub(University.GetSub(i));
                            }
                            break;
                        }

                    case "9": //Return
                        {
                            t = false;
                            break;
                        }

                }
            }
        }
    }
}
