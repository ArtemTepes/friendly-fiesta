﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using BLL;

namespace BLL.Tests
{
    public class UniversityTest
    {
        [Fact]
        public void DelSubject_ShouldReturnZero()
        {
            University nau = new University();
            nau.AddSubject("Math");

            nau.DelSubject("Math");

            Assert.Equal(0, nau.GetSubCount());
        } 
        
        [Fact]
        public void GetIndex_ShouldReturnZero()
        {
            University nau = new University();
            nau.AddSubject("Math");

            int index = nau.GetIndex("Math");

            Assert.Equal(0, index);
        }

        [Fact]
        public void ChangeGroupName_ShouldReturnZero()
        {
            University nau = new University();
            nau.AddGroup("221");

            nau.ChangeGroupName("221", "222");

            Assert.Equal("222" , nau.GetGroup()[0].GetName());
        }

        [Fact]
        public void AddStudent_ShouldReturnDoesNotContained()
        {
            University nau = new University();
            Student st = new Student("art", "ste", "123");

            nau.AddStudent(st, "221");            

            Assert.DoesNotContain(st, nau.GetStud());
        }

        [Fact]
        public void AddStudent_ShouldReturnContains()
        {
            University nau = new University();
            Student st = new Student("art", "ste", "123");
            nau.AddGroup("221");

            nau.AddStudent(st, "221");

            Assert.Contains(st, nau.GetStud());
        }

        [Fact]
        public void DelStudent_ShouldReturnDoesNotContained()
        {
            University nau = new University();
            Student st = new Student("art", "ste", "123");
            nau.AddGroup("221");

            nau.AddStudent(st, "221");
            nau.DelStudent("123");


            Assert.DoesNotContain(st, nau.GetStud());
        }

        [Fact]
        public void IsExistSt_ShouldReturnZero()
        {
            University nau = new University();
            Student st = new Student("art", "ste", "123");
            nau.AddGroup("221");

            nau.AddStudent(st, "221");
            int i = nau.IsExistSt("123");

            Assert.Equal(1, i);
        }

        [Fact]
        public void IsExistSub_ShouldReturnZero()
        {
            University nau = new University();
            nau.AddSubject("Math");

            
            int i = nau.IsExistSub("Math");

            Assert.Equal(1, i);
        }

        [Fact]
        public void SearchStudentId_r_ShouldReturnZero()
        {
            University nau = new University();
            Student st = new Student("art", "ste", "123");
            nau.AddGroup("221");

            nau.AddStudent(st, "221");

            Student st2 = nau.SearchStudentId_r("123");

            Assert.Equal(st2, st);
        }

        [Fact]
        public void ExistGroup_ShouldReturnZero()
        {
            University nau = new University();
            nau.AddGroup("221");

            int i = nau.ExistGroup("221");
            
            Assert.Equal(1, i);
        }

        [Fact]
        public void DelGroup_ShouldReturnDoesNotContained()
        {
            University nau = new University();
            Group group = new Group("221");
            nau.AddGroup("221");

            nau.DelGroup("221");

            Assert.DoesNotContain(group, nau.GetGroup());
        }

    }
}
