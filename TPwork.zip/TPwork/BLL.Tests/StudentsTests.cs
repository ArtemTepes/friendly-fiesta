﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BLL.Tests
{
    public class Students
    {
        [Fact]

        public void GetAvg_ShouldReturnZero()
        {
            University nau = new University();
            nau.AddSubject("Math");
            nau.AddSubject("Oop");
            nau.AddGroup("221");
            Student st = new Student("Art", "Ste", "223");
            nau.AddStudent(st, "221");

            st.SetEst(5, 0);
            st.SetEst(3, 1);
            st.Avg();

            Assert.Equal(4, st.GetAvg());
        }

    }
}
